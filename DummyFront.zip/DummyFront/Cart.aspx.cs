﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class Cart : System.Web.UI.Page
    {

        Service2Client client = new Service2Client();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DisplayCart();
            }
        }

        private void DisplayCart()
        {
            // Retrieve cart from session
            List<Product> cart = Session["Cart"] as List<Product>;

            if (cart == null || cart.Count == 0)
            {
                lblMessage.Text = "Your cart is empty.";
                return;
            }

            // Create table
            Table tbl = new Table();
            tbl.BorderWidth = 1;
            TableHeaderRow header = new TableHeaderRow();
            header.Cells.Add(new TableHeaderCell { Text = "Product" });
            header.Cells.Add(new TableHeaderCell { Text = "Price" });
            header.Cells.Add(new TableHeaderCell { Text = "Quantity" });
            header.Cells.Add(new TableHeaderCell { Text = "Total" });
            tbl.Rows.Add(header);

            decimal grandTotal = 0;

            // Count quantities
            var productCount = new Dictionary<int, int>();
            foreach (var p in cart)
            {
                if (productCount.ContainsKey(p.Product_ID))
                    productCount[p.Product_ID]++;
                else
                    productCount[p.Product_ID] = 1;
            }

            // Display each product
            foreach (var kvp in productCount)
            {
                int productId = kvp.Key;
                int quantity = kvp.Value;

                Product prod = cart.Find(p => p.Product_ID == productId);

                TableRow row = new TableRow();
                row.Cells.Add(new TableCell { Text = prod.Product_Name });
                row.Cells.Add(new TableCell { Text = "$" + prod.Product_Price });
                row.Cells.Add(new TableCell { Text = quantity.ToString() });
                row.Cells.Add(new TableCell { Text = "$" + (prod.Product_Price * quantity) });


                grandTotal += prod.Product_Price * quantity;
                tbl.Rows.Add(row);
            }

            // Add grand total row
            TableRow totalRow = new TableRow();
            TableCell cell = new TableCell { Text = "Grand Total", ColumnSpan = 3, HorizontalAlign = HorizontalAlign.Right };
            totalRow.Cells.Add(cell);
            totalRow.Cells.Add(new TableCell { Text = "$" + grandTotal });
            tbl.Rows.Add(totalRow);

            phCart.Controls.Add(tbl);

        }

    }
}