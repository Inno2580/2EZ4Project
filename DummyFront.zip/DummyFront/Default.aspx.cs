﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class _Default : Page
    {
        Service2Client client = new Service2Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            //var prod = client.getProduct(5);
        }
    }
}