﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        Service2Client client = new Service2Client();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignin_Click(object sender, EventArgs e)
        {
            //Get user info
            String user_email = txtEmail.Text;
            String user_password = txtPassword.Text;

            //Login user

            User user = client.login(user_email, user_password);
            if( user != null) //Exists
            {
                Session["ID"] = user.User_ID;
                
                Session["CustomerName"] = user.User_Name;
                Session["CustomerEmail"] = user.User_Email;

                if (user.User_Type.Equals('M'))
                {
                    Response.Redirect("admin_orders.aspx");
                    return;
                }

                Response.Redirect("index.aspx");
            }
            else{
                txtEmail.Text = "EHH";
            }

        }
    }
}