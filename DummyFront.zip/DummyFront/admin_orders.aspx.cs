﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class admin_orders : System.Web.UI.Page
    {
        Service2Client client = new Service2Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindOrders();
            }
        }

        private void BindOrders()
        {
            
            List<Order> orders = client.getOrders().ToList();

            if (orders != null && orders.Count > 0)
            {
                rptOrders.DataSource = orders;
                rptOrders.DataBind();
            }
            else
            {
                lblMessage.Text = "No orders found.";
            }
        }

        protected void rptOrders_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int orderId = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "Process":
                    // TODO: Call WCF to update delivery status

                    

                    BindOrders();
                    break;

                case "ViewDetails":
                    // Redirect to order details page with Order_ID as query string
                    Response.Redirect("order_details.aspx?orderID=" + orderId);
                    break;
            }
        }

    }
}