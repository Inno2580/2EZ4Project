﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class admin_report : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateReport();
            }
        }

        private void GenerateReport()
        {
            Service2Client client = new Service2Client();

            // 1. Get all orders
            List<Order> orders = client.getOrders().ToList();
            if (orders == null || orders.Count == 0)
            {
                lblMessage.Text = "No orders found.";
                return;
            }

            // 2. Calculate summary metrics
            lblTotalOrders.Text = orders.Count.ToString();

            // Assuming the string contains "Pending" for pending orders
            lblPendingOrders.Text = orders.Count(o => o.Order_Delivery_Status == "Pending").ToString();


            decimal totalRevenue = 0;
            Dictionary<int, int> productQuantityMap = new Dictionary<int, int>();
            Dictionary<int, decimal> productRevenueMap = new Dictionary<int, decimal>();
            Dictionary<int, string> productNames = new Dictionary<int, string>();

            foreach (var order in orders)
            {
                List<Invoiceline> lineItems = client.getIvoiceLineItems(order.Invoice_ID).ToList();

                foreach (var line in lineItems)
                {
                    Product product = client.getProduct((int)line.Product_ID);

                    // Total revenue
                    decimal lineRevenue = (decimal)(product.Product_Price * line.Invoiceline_Quantity);
                    totalRevenue += lineRevenue;

                    //// Track product quantity
                    //if (productQuantityMap.ContainsKey(product.Product_ID))
                    //    productQuantityMap[product.Product_ID] += line.Invoiceline_Quantity;
                    //else
                    //    productQuantityMap[product.Product_ID] = (int)line.Invoiceline_Quantity;

                    //// Track product revenue
                    //if (productRevenueMap.ContainsKey(product.Product_ID))
                    //    productRevenueMap[product.Product_ID] += lineRevenue;
                    //else
                    //    productRevenueMap[product.Product_ID] = lineRevenue;

                    //productNames[product.Product_ID] = product.Product_Name;
                }
            }

            lblTotalRevenue.Text = totalRevenue.ToString("F2");

            // 3. Prepare top-selling products list
            var topProducts = productQuantityMap.Select(p => new
            {
                Product_Name = productNames[p.Key],
                QuantitySold = p.Value,
                Revenue = productRevenueMap[p.Key]
            })
            .OrderByDescending(p => p.QuantitySold)
            .Take(10) // top 10 products
            .ToList();

            rptTopProducts.DataSource = topProducts;
            rptTopProducts.DataBind();
        }
    }
}