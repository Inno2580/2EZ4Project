﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class indexaspx : System.Web.UI.Page
    {
        Service2Client client = new Service2Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            

            dynamic lstProductsSolar = client.getActiveProducts(1);
            rptSolar.DataSource = lstProductsSolar;
            rptSolar.DataBind();

            dynamic lstProductsWater = client.getActiveProducts(2);
            rptWater.DataSource = lstProductsWater;
            rptWater.DataBind();

            dynamic lstProductsSecurity = client.getActiveProducts(3);
            rptSecurity.DataSource = lstProductsSecurity;
            rptSecurity.DataBind();


                AttachAddToCartHandlers(this.Page);

        }

        private void AttachAddToCartHandlers(Control parent)
        {
            foreach (Control ctrl in parent.Controls)
            {
                if (ctrl is HtmlButton btn)
                {
                    // Check if button has the class "add-to-cart"
                    if (btn.Attributes["class"] != null && btn.Attributes["class"].Contains("add-to-cart"))
                    {
                        btn.ServerClick += AddToCart_Click;
                    }
                }

                // Recursive for nested controls
                if (ctrl.HasControls())
                {
                    AttachAddToCartHandlers(ctrl);
                }
            }
        }

        protected void AddToCart_Click(object sender, EventArgs e)
        {
            Service2Client client = new Service2Client();
            HtmlButton btn = sender as HtmlButton;
            if (btn != null)
            {
                int productId = int.Parse(btn.Attributes["data-product-id"]);
                Product product = client.getProduct(productId);
                AddProductToCart(product);
            }
          
        }

        protected void AddProductToCart(Product product)
        {
            // Get the cart from session or create a new one
            var cart = Session["Cart"] as Dictionary<Product, int> ?? new Dictionary<Product, int>();

            // Check if a product with the same Product_ID is already in the cart
            var existingProduct = cart.Keys.FirstOrDefault(p => p.Product_ID == product.Product_ID);

            if (existingProduct != null)
            {
                // Product already in cart -> increment quantity
                cart[existingProduct]++;
            }
            else
            {
                // Product not in cart -> add with quantity 1
                cart.Add(product, 1);
            }

            // Save the updated cart back to session
            Session["Cart"] = cart;
        }

    }
}