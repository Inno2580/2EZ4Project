﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class invoice_details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int invoiceId = Convert.ToInt32(Request.QueryString["invoiceId"]);
                LoadInvoiceDetails(invoiceId);
            }
        }

        private void LoadInvoiceDetails(int invoiceId)
        {
            Service2Client client = new Service2Client();
          

            var lineItems = client.getIvoiceLineItems(invoiceId).Select(li =>
            {
                var product = client.getProduct((int)li.Product_ID);
                return new
                {
                    Product_Name = product.Product_Name,
                    Product_Price = product.Product_Price,
                    Quantity = li.Invoiceline_Quantity,
                    Subtotal = product.Product_Price * li.Invoiceline_Quantity
                };
            }).ToList();

            rptInvoiceLines.DataSource = lineItems;
            rptInvoiceLines.DataBind();
        }

    }
}