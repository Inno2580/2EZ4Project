﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class invoice_history : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadInvoices();
            }
        }

        private void LoadInvoices()
        {
            int customerId = Convert.ToInt32(Session["ID"]);
            Service2Client client = new Service2Client();

            dynamic invoices = client.getInvoices(customerId).ToList();

            rptInvoices.DataSource = invoices;
            rptInvoices.DataBind();
        }

    }
}