﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class order_details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int orderId;
                if (int.TryParse(Request.QueryString["orderId"], out orderId))
                {
                    LoadOrderDetails(orderId);
                }
            }
        }

        private void LoadOrderDetails(int orderId)
        {
            Service2Client client = new Service2Client();

            // 1. Get the Order
            Order order = client.getOrder(orderId);
            if (order == null) return;

            lblOrderId.Text = order.Order_ID.ToString();
            lblInvoiceId.Text = order.Invoice_ID.ToString();
            lblCustomerId.Text = order.Customer_ID.ToString();
            lblStatus.Text = order.Order_Delivery_Status;
            lblOrderDate.Text = order.Order_Date.ToString("yyyy-MM-dd");

            // 2. Get all invoice line items for this order
            List<Invoiceline> lineItems = client.getIvoiceLineItems(order.Invoice_ID).ToList();

            // 3. Map to a view model for the repeater
            var orderItems = new List<dynamic>();
            foreach (var line in lineItems)
            {
                Product product = client.getProduct((int)line.Product_ID);
                orderItems.Add(new
                {
                    Product_Name = product.Product_Name,
                    Product_Price = product.Product_Price,
                    Quantity = line.Invoiceline_Quantity,
                    Subtotal = product.Product_Price * line.Invoiceline_Quantity
                });
            }

            rptOrderLines.DataSource = orderItems;
            rptOrderLines.DataBind();
        }
    }
}