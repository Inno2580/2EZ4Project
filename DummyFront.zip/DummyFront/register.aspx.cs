﻿using DummyFront.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DummyFront
{
    public partial class register : System.Web.UI.Page
    {
        Service2Client client = new Service2Client();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignup_Click(object sender, EventArgs e)
        {
            //Get info from user
            String user_name = txtName.Text;
            String user_surname = txtSurname.Text;
            String user_phone_number = txtPhoneNumber.Text;
            String user_email = txtEmail.Text;
            String user_password = txtPassword.Text;
            String user_rePW = txtRePassword.Text;
            char user_type = txtUserType.Text.ToCharArray()[0];
            //Register to db
            int response = client.Register(user_name, user_password, user_phone_number, user_email, user_password, user_rePW, user_type);

            if (response == 0) //Successful
            {
            
                Response.Redirect("Login.aspx");

            }
            else if(response == 1) //User already exists, unsuccessful
            {
                txtName.Text = "User already exists";
            }
            else if(response == -1) //Internal error, unsuccessful
            {
                txtName.Text = "Damn bro";
            }


        }
    }
}